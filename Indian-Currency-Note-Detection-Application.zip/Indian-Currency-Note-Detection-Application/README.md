# Virtual Eye - A Blind Aid
It's an Android Application to help Visually impaired people.

## Features:
### Recognize Text :
1. Tap OCR button on Main Screen
2. Tap to listen text in the front of camera and Long Press to manage the text in Text Manager
    
### Recognize Currency :
1. Tap Currency button on Main Screen
2. Tap to listen detected currency

### Translate Text :
1. Tap Translate button on Main Screen
2. Select target language from the target language spinner
3. Tap on Translate button on the bottom to start translation

### Text Manager:
Select options in the bottom of the screen to manage text
